package com.petstore.endpoint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetstoreDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetstoreDemoApplication.class, args);
	}

}
